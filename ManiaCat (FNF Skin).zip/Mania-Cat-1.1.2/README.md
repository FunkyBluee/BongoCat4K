# Mania-Cat
Bongo cat overlay for VSRG

Credits: u/PunyFlash and their bongo cat key tracker. It was helpful to see how they built theirs when trying to optimize this project.

Link to u/PunyFlash 's project: https://github.com/PunyFlash/Bongo-Cat

Now supports up to 8 keys. Make sure it is not minimized or it won't work. To change the config, open the Config 4/8k.exe and input the keys you want to set in order. If you want to change the config directly, google the virtual keycodes of the keys you want to set (or use this website https://keycode.info/ ). Use the (stays on top) .exes when you want to see the cat in-game (ONLY works in borderless). You can also edit the sprites if you don't like my shitty mspaint skill, just don't change their names. To record with fullscreen, use Game Capture instead of Window Capture for the bongo cat. All thanks to SoroCario for this solution.

Download:
https://github.com/malad1211/Mania-Cat/releases

Gameplay:
https://www.youtube.com/watch?v=dzJBNSbxG8I

Make it shows up in-game borderless example:
https://www.youtube.com/watch?v=AI8HFvQQLxY

Borderless Gameplay (recorded separately because OBS display capture kills my framerate even harder):
https://www.youtube.com/watch?v=mW64zBShEt8
